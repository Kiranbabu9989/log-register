<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
</head>
<style>
.table{border: 1px solid black;}
.table tr th{padding:10px;}
.table tr td{padding:10px;}
</style>
<body>
<table class="table ">
<tr>
<th>id</th>
<th>firstname</th>
<th>middlename</th>
<th>lastname</th>
<th>email</th>
<th>phone</th>
<th>password</th>
<th>confirmpassword</th>
<th>actions</th>
</tr>
<?php foreach ($data as $key => $value) { ?>
<tr>

<td><?php echo $value->id;?></td>
<td><?php echo $value->firstname;?></td>
<td><?php echo $value->middlename;?></td>
<td><?php echo $value->lastname;?></td>
<td><?php echo $value->email;?></td>
<td><?php echo $value->phone;?></td>
<td><?php echo $value->password;?></td>
<td><?php echo $value->confirmpassword;?></td>
<td><button><a href="<?php echo base_url();?>index.php/home/edit/<?php echo $value->id;?>" type="submit">edit</a></button></td>
<td><button><a href="<?php echo base_url();?>index.php/home/delete/<?php echo $value->id;?>" type="submit">delete</a></button></td>
</tr>
<?php } ?>



</table>
    
</body>
</html>