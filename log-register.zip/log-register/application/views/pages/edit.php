<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    </head>
    <style>

    </style>
<body>
  <h1 style="text-align: center;">Edit</h1>
  
  
  
<form action="" method="POST" style="text-align:center" class="form">



 <label> First Name  :</label><input type="text" name="firstname" value="<?php echo $view->firstname ?>;"> <span id="nameError"></span><br><br>
 

 <label> Middle Name :</label><input type="text" name="middlename" value="<?php echo $view->middlename ?>;" > <span id="nameError"></span><br><br>

 <label> Last Name   :</label> <input type="text"  name="lastname" value="<?php echo $view->lastname ?>" > <span id="nameError"></span><br><br>


 <label> Email : </label><input type="text"  name="email" value="<?php echo $view->email ?>" ><span id="emailError"></span><br><br>

 <label>Phone Number :</label><input type="phone" name="phone" value="<?php echo $view->phone ?>" ><span id="phoneError"></span><br><br>

 <label> Password  :</label><input type="password" name="password" value="<?php echo $view->password ?>" ><span id="usernameError"></span><br><br>

 <label> Confirm Password  :</label><input type="password" name="confirmpassword"  value="<?php echo $view->confirmpassword ?>"><span id="usernameError"></span><br><br>

 <input type="submit" value="update" name="submit" id="submit"><br><br>

 click here to view : <a href="<?php echo base_url();?>/index.php/home/viewall"><input type="button" value="view"></a>


</form>    

</body>
</html>