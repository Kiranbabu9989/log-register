<!DOCTYPE html>
<html>
<head>
  <title>login</title>
</head>
<body>
  <h1 style="text-align: center;">login</h1>
  <form style="text-align: center;" method="post">
    Email id :<input type="text" name="email"><br/>
    <br/>
    Password:<input type="password" name="password"><br/>
    <br/>
    <input type="submit"  value="submit" name="submit"><br><br>
    
    Click here to register<a href="<?php echo base_url();?>/index.php/home/registration"> <input type="button" value="register" name="register"> </a>
    
  </form>

</body>
</html>