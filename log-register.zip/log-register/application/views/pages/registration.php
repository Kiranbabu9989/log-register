<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    #nameError,#emailError,#phoneError,#usernameError{
        color: red;
    }
    </style>
    <!--<script>
    window.onload=function(){
        var submit=document.getElementById("submit");
        submit.onclick=validate;
    }
// form elments (input,select,textarea) (.value) , content elements(h1,div ,etc..) (.innerHTML)
    var validate=() => {
      var name=document.getElementById("name");
      var email=document.getElementById("email");
      var phone=document.getElementById("phone");
      var username=document.getElementById("username");
  var nameValue=name.value;
  var emailValue=email.value;
  var phoneValue=phone.value;
  var usernameValue=username.value;

  var nameError=document.getElementById("nameError");
  var emailError=document.getElementById("emailError");
  var phoneError=document.getElementById("phoneError");
  var usernameError=document.getElementById("usernameError");

  //alert(nameValue+emailValue+phoneValue+usernameValue);
  if(nameValue=='' || nameValue==null){
     // alert("please enter name");
     nameError.innerHTML="please enter name";
  }
  if(emailValue=='' || emailValue==null){
     // alert("please enter name");
     emailError.innerHTML="please enter email";
  }
  if(phoneValue=='' || phoneValue==null){
     // alert("please enter name");
     phoneError.innerHTML="please enter phone";
  }
  if(usernameValue=='' || usernameValue==null){
     // alert("please enter name");
     usernameError.innerHTML="please enter username";
  }
    }
    </script>-->
    </head>
    <style>

    </style>
<body>
  <h1 style="text-align: center;">Registraion</h1>
  
<form action="" method="post" style="text-align:center" class="form">


<div class="ttt">
 <label> First Name  :</label><input type="text" name="firstname" id="firstname" required> <span id="nameError"></span><br><br>
 

 <label> Middle Name :</label><input type="text" name="middlename" id="middlename" required> <span id="nameError"></span><br><br>

 <label> Last Name   :</label> <input type="text"  name="lastname"id="lastname" required> <span id="nameError"></span><br><br>


 <label> Email : </label><input type="text"  name="email" id="email" required><span id="emailError"></span><br><br>

 <label>Phone Number :</label><input type="phone" name="phone" id="phone" required><span id="phoneError"></span><br><br>

 <label> Password  :</label><input type="password" name="password" id="password" required><span id="usernameError"></span><br><br>

 <label> Confirm Password  :</label><input type="password" name="confirmpassword" required id="password"><span id="usernameError"></span><br><br>

 <input type="submit" value="register" name="submit" id="submit"><br><br>

 Click here to login<a href="<?php echo base_url();?>/index.php/home"> <input type="button" value="login" name="register"> </a>
 </div>
</form>    

</body>
</html>