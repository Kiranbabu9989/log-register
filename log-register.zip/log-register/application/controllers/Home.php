<?php 
class Home extends CI_Controller{

	public function __CONSTRUCT(){
		parent::__CONSTRUCT();
		$this->load->model('login_model');
	}

public function index(){
	$data= new stdClass();

	if(isset($_POST['submit'])){
		$data= new stdClass();
		$data->email=$this->input->post('email');
		$data->password=$this->input->post('password');
		$res=$this->login_model->login($data);
		if($res){
			redirect('home/viewall');
		}else{
			print_r('please register');
		}
		
	}

	$this->load->view('pages/login');

}
public function registration(){
	$data= new stdClass();
	if(isset($_POST['submit'])){
		
		$data->firstname=$this->input->post('firstname');
		$data->middlename=$this->input->post('middlename');
		$data->lastname=$this->input->post('lastname');
		$data->email=$this->input->post('email');
		$data->phone=$this->input->post('phone');
		$data->password=$this->input->post('password');
		$data->confirmpassword=$this->input->post('confirmpassword');
		$this->login_model->registration($data);
		redirect('home/index');
	}
	$this->load->view('pages/registration');
	
}

public function viewall(){

	$res=$this->login_model->viewall();
	$this->load->view('pages/dashboard',array('data'=>$res));
}
public function edit(){
	$id=$this->uri->segment(3);
	$data= new stdClass();
	if(isset($_POST['submit'])){
		$data->id=$id;
		$data->firstname=$this->input->post('firstname');
		$data->middlename=$this->input->post('middlename');
		$data->lastname=$this->input->post('lastname');
		$data->email=$this->input->post('email');
		$data->phone=$this->input->post('phone');
		$data->password=$this->input->post('password');
		$data->confirmpassword=$this->input->post('confirmpassword');
		$res1=$this->login_model->update($data);
		
	}
	$res=$this->login_model->edit($id);
	$this->load->view('pages/edit',array('view'=>$res));
}
public function delete(){
	$id=$this->uri->segment(3);
	$res1=$this->login_model->delete($id);
	if($res1==true){
		redirect('home/viewall');
	}

}







}




?>