<?php

class login_model extends CI_Model{

public function login($data){
	$this->db->where(array('email'=>$data->email,'password'=>$data->password));
	$res=$this->db->get('registration')->num_rows();
	return $res;
}
public function registration($data){
	$result=$this->db->insert('registration',$data);
	return $result;
}


public function viewall(){
	$result=$this->db->get('registration')->result();
	return $result;
}


public function edit($id){
	$this->db->where('id',$id);
	$result=$this->db->get('registration')->row();
	return $result;
}
public function update($data){
	$this->db->where('id',$data->id);
	$result=$this->db->update('registration',$data);
	return $result;
}
public function delete($id){
	$this->db->where('id',$id);
	$result=$this->db->delete('registration');
	return $result;
}



}







?>